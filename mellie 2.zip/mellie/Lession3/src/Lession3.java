import java.util.Scanner;
//Programa ,koyato otpechatva sumata na N vuvedeni chisla ot keyb.N se vuvejda predvaritelno.
//Pri vuvejdane na vsyako cislo da se ispisva kolko ostavat za vuvejdane

public class Lession3 {
public static void main(String[] args) 
   {
	   Scanner s = new Scanner(System.in);
	   System.out.println("Enter how numbers you will calculate:  ");
	   int n=0;
	   n=s.nextInt();   
	   int sum=0;
	   int z=0;
	   
 
	   for (int i = 0; i <=n; i++) 
	   { 
		   n=z;
		   z--;
		   System.out.println("Enter "+z+" more numbers: ");
		   
		   n=s.nextInt();
		   
		   sum+=n;
		  		  					  		   
		   
	   }
	   System.out.println(sum);
   }
}
