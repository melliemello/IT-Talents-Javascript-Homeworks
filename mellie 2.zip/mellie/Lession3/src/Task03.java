import java.util.Scanner;
//

public class Task03 {
public static void main(String[] args) {
	Scanner s =new Scanner(System.in);
	
	int sum=0;
	int n=0;
	
	
	for (int i = 0; ; i++)
	{
		System.out.println("Enter a number: ");
		n=s.nextInt();
		
		sum*=n;
		if (n==1)
		{
			break;
			
		}
			
	}
	System.out.println(sum);
	
}
}
