
public class Task06 {
//Da se vuvede programa,koyato vuvejda 2 chisla M i N ot keyB i printva Vsichki chisla otM do N;
}
