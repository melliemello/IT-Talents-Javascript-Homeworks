
public class Task07 {
//Da se sustavi programa,koyato vuvejda 2 chisla M i N ot keyB i print:
// - sumata na vischki v intervala; proizvedenieto im;
}
