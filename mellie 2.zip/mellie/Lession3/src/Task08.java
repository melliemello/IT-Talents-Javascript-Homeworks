import java.util.Scanner;


public class Task08 {
//Dadeni sa 2 ednakvi neprozrachni liniiki. Po dylzhinata na vsyaka,na ravni intervali edna ot druga,na ednakvo
//razstoyanie ot ruba sa probiti dupki.Dypkite zapovcvat ot 0-levoto delenie.Raztoyanieto m/u dupkite e M milimetra za 1=ta liniika
// i N milimetra za drugata.Dyljinata na liniikite e L.
//M,N i L se vuvejdat ot klavieturata.Da se izvede kolko dupki shet suvpadata , ako liniikite se postavyat v/u druga.
	
public static void main(String[] args) {
	int l,m,n;
	Scanner s=new Scanner(System.in);
	System.out.println("Enter lenght for M and L: ");
	l=s.nextInt();
	System.out.println("Enter distance for M: ");
	m=s.nextInt();
	System.out.println("Enter distance for L: ");
	n=s.nextInt();
	int counter=0;
	int counter2=0;
	int sum1=0;
	int sum2=0;
	
	for (int i = 0; i <=l; i+=m) 
	 {	
		for (int j = 0; j <=l; j+=n) 
		 {
		
			if ( i == j )
			 {
				counter++;
				
			 }								
		 }	
	
	 }
	System.out.println(counter);
	s.close();
	   } 
}
