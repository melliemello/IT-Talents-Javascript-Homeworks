import java.util.Scanner;

//Da se napishe programa,koyato pri vuvedeni M&N izvejda ot konzolata vs chisla v intervala m/u tyah ,koito se delyat na 1=3,2=2,3=5;
public class Task09 {
public static void main(String[] args) {
		Scanner s =new Scanner(System.in); 
		int m,n;
		
		System.out.println("Enter M: ");
		m=s.nextInt();
		System.out.println("Enter N: ");
		n=s.nextInt();
		
		for (int i = m; i <n ; i++)		
		{
			if (i%3==0 && i%2==0 && i%5==0 ) 
			{
				System.out.print(i+" is devided by 2,3 and 5"+"," );
			}
			else if (i%3==0 && i%2==0) 
			{
				System.out.print(i+" is devided by 2 and 3"+",");
			}
			else if (i%3==0 && i%5==0) 
			{
				System.out.print(i+" is devided by 2 and 5"+",");
			}
			else if (i%3==0)
			{
				System.out.print(i+" is bedevided by 3 "+",");
			}
				
			else if (i%2==0) 
			{
				System.out.print(i+" is devided by 3 "+",");
			}
			else if (i%5==0) 
			{
				System.out.print(i+" is devided by 5 "+",");
			}
		}
		
			
	}

}
