import java.util.Scanner;

//Da se napishe programa.koyato priema chisla ot klaviatura do vuvejdane na 0 i izvejdana broya na vuvedenite otricatelni chisla
public class Task10 {
	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
		int n=0;
		int counter=0;
		for (int i = 0; ; i++) 
		{
			System.out.println("Enter a number : ");
			n=s.nextInt();
			if (n<0) 
			{
				counter++;
			}
			if (n==0)
			{
				break;
			}
			
		}
		System.out.println(counter);
	}

}
