import java.util.Scanner;


public class Task11 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int k,n;
		int sum=0;
		int counter=0;
		System.out.println("Enter K: ");
		k=s.nextInt();
		
		for ( ; ; )
		{
			System.out.println("Enter a number: ");
			
			n=s.nextInt();
			
			sum+=n;
			
			counter++;
			if (sum<=k) 
			{
				
				break;
			}
			
		}
		
		System.out.println(counter);
		s.close();
		
	}

}
