
public class Task12 {

}
