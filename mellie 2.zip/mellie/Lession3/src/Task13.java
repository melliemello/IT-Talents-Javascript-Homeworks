import java.util.Scanner;


public class Task13 {
public static void main(String[] args) {
	
	Scanner s = new Scanner(System.in);
	int max = 0 ;
	
	boolean hasNegative = false;  //flag 
	
	
	while (true) 
		
				{
						System.out.println("Please enter a number!");
		                int input = s.nextInt();
		                
		                if (!hasNegative && input<0)
		                {
							max = input;
							hasNegative=true;
						}
		                else
		                if (input < 0 && max<input) 
		                {
							max=input;
						}
		                if (hasNegative) 
		                {
		                	System.out.println(max);
						}
		                else 
		                {
		                	System.out.println("No negative imput yet!");
						}
				}	
       }
}
