import java.util.Scanner;
//
public class Task14 {
public static void main(String[] args) {
		Scanner s =new Scanner(System.in); 
		
		
		int weight,result,players;
		
		int counter=0;
		int winner=0;
		int maxResult=0;
		int tempResult=0;
		int maxWeight=0;
		int tempWeight=0;
		int winningWeight=0;
		int winningResult=0;
		
		System.out.println("Enter number of players : ");
		players=s.nextInt();
		
		for (int i = 0; i < players; i++) 
		{
			counter++;
			System.out.println("Enter result of player " + counter );
			result=s.nextInt();
			
			System.out.println("Enter weight of player " + counter  );
			weight=s.nextInt();
			
			if (result>maxResult) 
			{
				maxResult=result;
				winningWeight=weight;
				winner=i;
			}
			else
			if (weight>tempWeight) 
			{
				maxWeight=weight;
			}
			
			
			
				
			
					System.out.println(winner);
			
		}
	}
	
}
