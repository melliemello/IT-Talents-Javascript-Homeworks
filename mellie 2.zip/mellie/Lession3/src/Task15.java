import java.util.Scanner;


public class Task15 {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter a number : ");
	int n=0;
	n=s.nextInt();
	int number=0;
	int counter=0;
	System.out.println(n);
	System.out.println();
	for (int i = 0; i < n; i++)
	{
		counter++;
	System.out.print("Enter the diggit of your number : ");
		n=s.nextInt();
		number=n;
		System.out.println(counter);
	}
	
}
}
