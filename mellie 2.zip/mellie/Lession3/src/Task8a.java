import java.util.Scanner;


public class Task08 {
//Dadeni sa 2 ednakvi neprozrachni liniiki. Po dylzhinata na vsyaka,na ravni intervali edna ot druga,na ednakvo
//razstoyanie ot ruba sa probiti dupki.Dypkite zapovcvat ot 0-levoto delenie.Raztoyanieto m/u dupkite e M milimetra za 1=ta liniika
// i N milimetra za drugata.Dyljinata na liniikite e L.
//M,N i L se vuvejdat ot klavieturata.Da se izvede kolko dupki shet suvpadata , ako liniikite se postavyat v/u druga.
	
public static void main(String[] args) {
	int l,m,n;
	Scanner s=new Scanner(System.in);
	System.out.println("Enter lenght for M and L: ");
	l=s.nextInt();
	System.out.println("Enter distance for M: ");
	m=s.nextInt();
	System.out.println("Enter distance for L: ");
	n=s.nextInt();
	int counter=0;
	//---Opitmizrai kato napravish sluchei v koito broi vinagi po-golyamoto i deli na drugito.... if (i%m) { pyk e za j+=n;
	for (int i = 0,j = 0; i <=l && j<=l;i+=m, j+=n)		
	{
		if (i%m==0 && i%n==0);
		{
			counter++;
		}			
	}
	System.out.println(counter);
	s.close();
 }
}
